
const users = [
    {
        name: "Fulanita Perez",
        email: "fulanita@gmail.com",
        age: 30,
        image: "https://picsum.photos/id/1011/200/300",
        genre: "Mujer",
        vaccinated: true

    },
    {
        name: "Matias Sanchez",
        email: "matias@gmail.com",
        age: 20,
        image: "https://picsum.photos/id/1005/200/300",
        genre: "Hombre",
        vaccinated: false
    },
    {
        name: "Susana Distancia",
        email: "susy@gmail.com",
        age: 52,
        image: "https://picsum.photos/id/1027/200/300",
        genre: "Mujer",
        vaccinated: false
    },
    {
        name: "Maria Antonieta Doe",
        email: "maria@gmail.com",
        age: 15,
        image: "https://picsum.photos/id/342/200/300",
        genre: "Mujer",
        vaccinated: true
    },
    {
        name: "Korra",
        email: "korra@gmail.com",
        age: 16,
        image: "https://elcomercio.pe/resizer/ZFLIcf4cPuTlkY5biZEGPg7e-nM=/1200x1200/smart/filters:format(jpeg):quality(75)/cloudfront-us-east-1.images.arcpublishing.com/elcomercio/B7NLPCPW7BANBEEJOMMRTYTHIY.jpg",
        genre: "Mujer",
        vaccinated: false
    },
    {
        name: "Angelica Pickles",
        email: "angelica@gmail.com",
        age: 3,
        image: "https://static.wikia.nocookie.net/doblaje/images/1/19/Angelica_Pickles.png/revision/latest?cb=20130225180210&path-prefix=es",
        genre: "Mujer",
        vaccinated: false
    },
    {
        name: "Calamardo Tentaculos",
        email: "angelica@gmail.com",
        age: 26,
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTZ-WKCVQkTItzvnuxE-qV7j2TK6EDGtm9Kwg&usqp=CAU",
        genre: "Hombre",
        vaccinated: false
    },
    {
        name: "Principe Zuko",
        email: "zuko@gmail.com",
        age: 16,
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQZDdKUcZtxxzG3vh0cuYY5dHSnumrBGpY7Dw&usqp=CAU",
        genre: "Hombre",
        vaccinated: true
    }
]

//EVENT LISTENERS
// addEventListener
/*  
    elemento.addEventListener( "evento", (event) => {
        //Que se va a llevar a cabo cuando se detecte el "evento" sobre el elemento
    })
*/
/*
const boton = document.querySelector( ".btn-delete" )
const imagen = document.querySelector("img")
*/
// elemento.remove()
/*
boton.addEventListener( "click", evento =>{
    console.log( evento )
    imagen.remove()
})
*/
/*
boton.addEventListener( "click", e => {
    const contenedor = e.target.parentElement
    contenedor.remove()
})
*/

// padre.removeChild( "hijoQueQuieroEliminar" )
/*
const lista = document.querySelector( "ul" )
const boton = document.querySelector( "button" )

boton.addEventListener( "click", e => {
    lista.removeChild( lista.lastElementChild )
})
*/
/*
const section = document.createElement( "section" )
const body = document.querySelector("body")

body.appendChild( section )


section.innerHTML = `<h2 class="text-red"> TITULO </h2>`
*/

